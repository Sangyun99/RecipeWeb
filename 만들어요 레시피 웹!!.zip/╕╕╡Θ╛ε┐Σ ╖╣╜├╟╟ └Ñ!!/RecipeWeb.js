// index.html에서 버튼 클릭 시 두 번째 페이지로 이동하는 함수
function moveToSecondPage() {
    window.location.href = "main.html";
}

// 버튼 클릭 이벤트에 함수 연결
var moveToSecondPageButton = document.getElementById("moveToSecondPageButton");
moveToSecondPageButton.addEventListener("click", moveToSecondPage);
